<template>
  <div class="h-100 d-flex align-center justify-space-between">
    <!-- 👉 Footer: left content -->
     <span></span>
    <span class="d-md-flex gap-x-4 text-primary d-none">
      I-Robotics
      &copy;
      {{ new Date().getFullYear() }}
    </span>
    <span></span>
  </div>
</template>
